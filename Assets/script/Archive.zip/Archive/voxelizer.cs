using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using AssemblyCSharp;
using System.Threading;

public class Voxelizer:MonoBehaviour{
	/*Mesh m;

	Voxelizer(Mesh m){
		this.m = m;
	}*/
//	public GameObject brick;
	public Transform Canvas;
	public Transform LoadingBar;
	public Transform percentText;
	public Transform LoadingText;

	private Grid[,,] grids ;
	private Thread t1;

	float max_x;
	float min_x;
	
	float max_y;
	float min_y;
	
	float min_z;
	float max_z;
	float gridsize;
	int totalX;
	int totalY;
	int totalZ;

	private List<Grid> voxels;
	private Dictionary<ColorSpecification,List<Vector3>>voxelsCoordinate;
	private VoxelBuffer buffer;
	private bool onLoading = false;
	private Texture2D texture_black;
	private Texture2D texture_white;
	private float percentage;

	public void Start(){
		Canvas.gameObject.SetActive(false);
		LoadingBar.GetComponent<Image> ().fillAmount = 0;
	}

	public void FixedUpdate(){
	
		if (onLoading) {
			if (percentage < 1) {

				percentText.GetComponent<Text> ().text = String.Format("{0:0.00}",percentage*100) + "%";
				LoadingText.gameObject.SetActive (true);
			} else {
				LoadingText.gameObject.SetActive (false);
				percentText.GetComponent<Text> ().text = "DONE!";
			}
			Canvas.gameObject.SetActive (true);
			LoadingBar.GetComponent<Image> ().fillAmount = percentage;
		} else {
			Canvas.gameObject.SetActive (false);
		}

	}

	private Vector2 getIncenter(Vector2 uv1, Vector2 uv2, Vector2 uv3){
		float tir_a = Vector2.Distance(uv1,uv2);
		float tir_b = Vector2.Distance(uv2,uv3);
		float tir_c = Vector2.Distance(uv3,uv1);
		
		float newU = (tir_a*uv1.x+tir_b*uv2.x+tir_c*uv3.x)/(tir_a+tir_b+tir_c);
		float newV = (tir_a*uv1.y+tir_b*uv2.y+tir_c*uv3.y)/(tir_a+tir_b+tir_c);
		return new Vector2(newU, newV);
	}

	private bool isWithinDistance (Vector3 a, Vector3 b){
		float xdistance = Mathf.Abs(a.x - b.x);
		float ydistance = Mathf.Abs(a.y - b.y);
		float zdistance = Mathf.Abs(a.z - b.z);
		if (xdistance > gridsize + float.Epsilon) {
			return false;
		}
		if (ydistance > gridsize/2.5f+ float.Epsilon) {
			return false;
		}
		if (zdistance > gridsize+ float.Epsilon) {
			return false;
		}
		return true;
	}

	private void addMidpt(Vector3 a, Vector3 b, Color color){
		float distance = Mathf.Pow (a.x - b.x, 2) + Mathf.Pow (a.y - b.y, 2) + Mathf.Pow (a.z - b.z, 2);
		distance = Mathf.Sqrt (distance);
		//distance < gridsize/3
		if (isWithinDistance(a,b)) {
			// points is aligned in two neighobour grid
			Vector3[] ptx = {a,b};
			int index;
			foreach(Vector3 pt in ptx){
				//calculate the closest grid array index of each point
				int ptX = Mathf.RoundToInt(((pt.x-min_x)/(max_x-min_x))*totalX);
				int ptY = Mathf.RoundToInt(((pt.y-min_y)/(max_y-min_y))*totalY);
				int ptZ = Mathf.RoundToInt(((pt.z-min_z)/(max_z-min_z))*totalZ);
				if(grids[ptX,ptY,ptZ] == null){
					//calculate the world coordinate of the center of the grid
					float realX = ((float)ptX /(float)totalX)*(max_x-min_x)+min_x;
					float realY = ((float)ptY /(float)totalY)*(max_y-min_y)+min_y;
					float realZ = ((float)ptZ /(float)totalZ)*(max_z-min_z)+min_z;
					
					grids[ptX,ptY,ptZ] = new Grid(realX,realY,realZ);
					grids[ptX,ptY,ptZ].setGPosition(ptX,ptY,ptZ);
					voxels.Add(grids[ptX,ptY,ptZ]);
					index = voxels.Count - 1;
				}else{
					index = voxels.IndexOf(grids[ptX,ptY,ptZ]);
				}
				voxels[index].addPoint(pt);
				voxels[index].AddColor(color);
			}
			return;
		} else {
			//line beetween two point is larger than the shortest grid length
			//line interesect more than one grid
			Vector3 subdivide = new Vector3((a.x+b.x)/2.0F,(a.y+b.y)/2.0F,(a.z+b.z)/2.0F);
			addMidpt(a,subdivide, color);
			addMidpt(subdivide,b, color);
		}
	}

	private void subdivideTriangle(Vector3 a, Vector3 b, Vector3 c, List<Vector2> uvs, Texture2D sourceTex, Color materialColor){

		//check whether the distance between points is less than the shortest grid length
		Vector3[] ptx = {a,b, c};
		bool valid = true;
		for (int i =1; i <=3; i++) {
			//float distance = Mathf.Pow (ptx[i%3].x-ptx[i-1].x, 2) + Mathf.Pow (ptx[i%3].y - ptx[i-1].y, 2) + Mathf.Pow (ptx[i%3].z - ptx[i-1].z, 2);
			//distance = Mathf.Sqrt (distance);
			if (!isWithinDistance(ptx[i%3],ptx[i-1])) {
				valid = false;
			}
		}

		if (!valid) {
			//subdivide a large triangle to four by cut each edge by half
			Vector3 ab = new Vector3((a.x+b.x)/2.0F,(a.y+b.y)/2.0F,(a.z+b.z)/2.0F);
			Vector3 ac = new Vector3((a.x+c.x)/2.0F,(a.y+c.y)/2.0F,(a.z+c.z)/2.0F);
			Vector3 bc = new Vector3((b.x+c.x)/2.0F,(b.y+c.y)/2.0F,(b.z+c.z)/2.0F);

			Vector2 uvab = (uvs[0]+uvs[1])/2;
			Vector2 uvac = (uvs[0]+uvs[2])/2;
			Vector2 uvbc = (uvs[1]+uvs[2])/2;

			List<Vector2> new_uvs = new List<Vector2>();
			//if the triangle is larger than the shortest grid length, subdivide the triangle again
			new_uvs.Add(uvs[0]);
			new_uvs.Add(uvab);
			new_uvs.Add(uvac);
			subdivideTriangle (a, ab, ac, new_uvs, sourceTex, materialColor);

			new_uvs.Clear();
			new_uvs.Add(uvs[1]);
			new_uvs.Add(uvab);
			new_uvs.Add(uvbc);
			subdivideTriangle (b, ab, bc, new_uvs, sourceTex, materialColor);

			new_uvs.Clear();
			new_uvs.Add(uvs[2]);
			new_uvs.Add(uvac);
			new_uvs.Add(uvbc);
			subdivideTriangle (c, ac, bc, new_uvs, sourceTex, materialColor);

			new_uvs.Clear();
			new_uvs.Add(uvab);
			new_uvs.Add(uvac);
			new_uvs.Add(uvbc);
			subdivideTriangle (ab, ac, bc, new_uvs, sourceTex, materialColor);
		} else {
			Color averageC = new Color(0,0,0,0);

			if(sourceTex!=null){
				Vector2 incenter = getIncenter(uvs[0],uvs[1],uvs[2]);
				Vector2 scale_offset = new Vector2(sourceTex.width,sourceTex.height);

				int sampleX = Mathf.RoundToInt(incenter.x*scale_offset.x);
				int sampleY = Mathf.RoundToInt(incenter.y*scale_offset.y);

				
				Color[] pix = sourceTex.GetPixels(sampleX, sampleY, 1 , 1);
				
				for(int j = 0; j < pix.Length; j++){
					averageC += (pix[j]*materialColor);
				}
				averageC /= pix.Length;
			}else{
				averageC = materialColor;
			}

			//add point to the grid
			addMidpt(a,b,averageC);
			addMidpt(a,c,averageC);
			addMidpt(b,c,averageC);
		}

	}


	public IEnumerator voxelize () {
		percentage = 0;

		onLoading = true;
		GameObject target = GameObject.Find ("Target");
		OBJ obj = target.GetComponent<OBJ> ();
		voxels = new List<Grid>();
		voxelsCoordinate = new Dictionary<ColorSpecification,List<Vector3>>();

		obj.onVoxelizing = true;

		GameObject[] gs = obj.ms;

		for (int a = 0; a < gs.Length; a++) {
			Mesh m = (gs[a].GetComponent(typeof(MeshFilter)) as MeshFilter).mesh;
			MeshRenderer mr = gs[a].GetComponent(typeof(MeshRenderer)) as MeshRenderer;
			Vector3[] meshVertices = m.vertices;
			//Debug.Log(m.uv.Count());
			/*for(int i = 0; i < m.uv.Count(); i++)
				Debug.Log(m.uv[i]);
			*/
		
			//Debug.Log(m.vertices.Count());
			//Debug.Log(m.triangles.Count());

			max_x = m.bounds.max.x;
			min_x = m.bounds.min.x;

			max_y = m.bounds.max.y;
			min_y = m.bounds.min.y;
			
			min_z = m.bounds.min.z;
			max_z = m.bounds.max.z;

			//set total number of grid to sampling
			//high resolution: 1000000
			//normal resolution: 250000
			//low resolution: 62500
			//very low resolution: 15625 (recommended for debug use)
			int totalgrid = 250000;

			float ny = (max_x - min_x)/((max_y - min_y)*2.5f);
			float nz = (max_x - min_x)/(max_z - min_z);
			totalX = Mathf.RoundToInt(Mathf.Pow(totalgrid * ny * nz,1.0f/2.5f));
			gridsize = (float)totalX;
			gridsize = (max_x - min_x)/gridsize;
			/*------------------create self-designed cooridinate------------------*/
			//calculate the total number of grids in term of the three axis
			totalX = Mathf.RoundToInt((max_x - min_x)/gridsize);
			totalY = Mathf.RoundToInt((max_y - min_y)/(gridsize/2.5f));
			totalZ = Mathf.RoundToInt((max_z - min_z)/gridsize);

			//3D array to save the information of each grid
			grids = new Grid[totalX+1,totalY+1,totalZ+1];
			/*
			//create grid in the 3D array
			for(int x=0; x< totalX+1; x++){
				for(int y=0; y< totalY+1; y++){
					for(int z=0; z< totalZ+1; z++){
						//calculate the world coordinate of the center of the grid
						float realX = ((float)x /(float)totalX)*(max_x-min_x)+min_x;
						float realY = ((float)y /(float)totalY)*(max_y-min_y)+min_y;
						float realZ = ((float)z /(float)totalZ)*(max_z-min_z)+min_z;

						grids[x,y,z] = new Grid(realX,realY,realZ);
						grids[x,y,z].setGPosition(x,y,z);	//useless
					}
				}
			}
			*/

			/*------------------Assign point to grid------------------*/

			int[] meshTriangles;
			float totalstep = 0;
			for(int num_mesh = 0; num_mesh < m.subMeshCount; num_mesh++){
				totalstep += (m.GetTriangles(num_mesh).Length)/3;
			}

			float stepCounter = 0;
			for(int num_mesh = 0; num_mesh < m.subMeshCount; num_mesh++){
				//meshTriangles = m.GetTriangles(num_mesh);
				meshTriangles = m.GetTriangles(num_mesh);
				Texture tex = mr.materials[num_mesh].GetTexture(0);
				Texture2D sourceTex = null;
				if(tex!=null){
					sourceTex = (tex as Texture2D);
				}
				
				for (int i = 0; i < meshTriangles.Length; i += 3)
				{
					//get the three vertice point of each triangle
					Vector3 p1 = meshVertices[meshTriangles[i + 0]];
					Vector3 p2 = meshVertices[meshTriangles[i + 1]];
					Vector3 p3 = meshVertices[meshTriangles[i + 2]];

					List<Vector2> uvs = new List<Vector2>();

					if(tex!=null){
						Vector2 uv1 = m.uv[meshTriangles[i+0]];
						Vector2 uv2 = m.uv[meshTriangles[i+1]];
						Vector2 uv3 = m.uv[meshTriangles[i+2]];
						
						uv1 = new Vector2(uv1.x < 0 ? uv1.x+1-((int)uv1.x) : uv1.x, 
						                  uv1.y < 0 ? uv1.y+1-((int)uv1.y) : uv1.y);
						uv2 = new Vector2(uv2.x < 0 ? uv2.x+1-((int)uv2.x) : uv2.x, 
						                  uv2.y < 0 ? uv2.y+1-((int)uv2.y) : uv2.y);
						uv3 = new Vector2(uv3.x < 0 ? uv3.x+1-((int)uv3.x) : uv3.x,
						                  uv3.y < 0 ? uv3.y+1-((int)uv3.y) : uv3.y);
						
						uv1 = new Vector2(uv1.x > 1 ? uv1.x-((int)uv1.x) : uv1.x, 
						                  uv1.y > 1 ? uv1.y-((int)uv1.y) : uv1.y);
						uv2 = new Vector2(uv2.x > 1 ? uv2.x-((int)uv2.x) : uv2.x,
						                  uv2.y > 1 ? uv2.y-((int)uv2.y) : uv2.y);
						uv3 = new Vector2(uv3.x > 1 ? uv3.x-((int)uv3.x) : uv3.x,
						                  uv3.y > 1 ? uv3.y-((int)uv3.y) : uv3.y);

						uvs.Add(uv1);
						uvs.Add(uv2);
						uvs.Add(uv3);
					}
					//push vertices to grid by subdividing the triangle
					subdivideTriangle(p1,p2,p3, uvs, sourceTex, mr.materials[num_mesh].color);

					stepCounter++;
					percentage = stepCounter/totalstep;
					//yield return new WaitForFixedUpdate();
					yield return null;
				}
			}

			(gs[a].GetComponent(typeof(MeshRenderer))as MeshRenderer).enabled = false;

			/*------------------render voxels------------------*/

			//brick.transform.localScale = new Vector3(gridsize,gridsize/3,gridsize);
			int counter = 0;

			for (int c= 0; c < (int)ColorSpecification.NUM_OF_COLOR; c++){
				voxelsCoordinate.Add((ColorSpecification)c,new List<Vector3>());
			}

			foreach(Grid grid in voxels){
				//set color (r,g,b,r) <-- rgb are ranged from 0 to 1
				/*
					Material material = new Material(Shader.Find ("Standard"));
					material.color = new Color(252.0f/255.0f, 255.0f/255.0f ,4.0f/255.0f, 1);
					brick.GetComponent<MeshRenderer>().material = material;
				*/
				//
				voxelsCoordinate[grid.nearestColor()].Add(grid.getPosition());
				counter++;

				//(Instantiate(brick,grid.getPosition(), Quaternion.identity) as GameObject).transform.parent = GameObject.Find("Voxelized").transform;
			}
			int max_vertice_gameObject = 2500;
			buffer = new VoxelBuffer();

			for (int c= 0; c < (int)ColorSpecification.NUM_OF_COLOR; c++){

				List<Vector3> coor = voxelsCoordinate[(ColorSpecification)c];

				if(coor.Count>0){
					List<GameObject> gos = new List<GameObject>();
					int index = 0;
					Color color;
					color = Grid.getColor((ColorSpecification)c);
					for(int i = coor.Count ; i > 0; i-=max_vertice_gameObject){
						GameObject go = new GameObject();
						go.transform.parent = GameObject.Find("Voxelized").transform;
						go.AddComponent(typeof(MeshFilter));
						go.AddComponent(typeof(MeshRenderer));
						gos.Add(go);
					}
					
					for(int i =0; i < gos.Count; i++){
						int count_coor = (coor.Count - i*max_vertice_gameObject >=max_vertice_gameObject)? max_vertice_gameObject : coor.Count - i*max_vertice_gameObject;
						buffer.draw(gos[i],coor.GetRange(i*max_vertice_gameObject,count_coor),gridsize,color);
						index++;
					}
					gos.Clear();
				}
			}

			/*
			for(int i = counter ; i > 0; i-=max_vertice_gameObject){
				GameObject go = new GameObject();
				go.transform.parent = GameObject.Find("Voxelized").transform;
				go.AddComponent(typeof(MeshFilter));
				go.AddComponent(typeof(MeshRenderer));
				gos.Add(go);
			}

			buffer = new VoxelBuffer();
			for(int i =0; i < gos.Count; i++){
				int count_coor = (voxels.Count - i*max_vertice_gameObject >=max_vertice_gameObject)? max_vertice_gameObject : voxels.Count - i*max_vertice_gameObject;
				buffer.draw(gos[i],voxels.GetRange(i*max_vertice_gameObject,count_coor),gridsize);
			}
/*
			for(int x=0; x< totalX+1; x++){
				for(int y=0; y< totalY+1; y++){
					for(int z=0; z< totalZ+1; z++){
						Grid grid = grids[x,y,z];
						if(!grid.isEmpty()){
							//set color (r,g,b,r) <-- rgb are ranged from 0 to 1
							/*if(x%2 == 0){
								Material material = new Material(Shader.Find ("Standard"));
								material.color = new Color(1.0f,0,0,1);
								brick.GetComponent<MeshRenderer>().material = material;
							}else{
								Material material = new Material(Shader.Find ("Standard"));
								material.color = new Color(252.0f/255.0f, 255.0f/255.0f ,4.0f/255.0f, 1);
								brick.GetComponent<MeshRenderer>().material = material;
							}

							Material material = new Material(Shader.Find ("Standard"));
							material.color = new Color(252.0f/255.0f, 255.0f/255.0f ,4.0f/255.0f, 1);
							brick.GetComponent<MeshRenderer>().material = material;

							(Instantiate(brick,grid.getPosition(), Quaternion.identity) as GameObject).transform.parent = GameObject.Find("Voxelized").transform;
							counter++;
						}
					}
				}
			}
*/
			Debug.Log (voxels.Count);
			voxelsCoordinate.Clear();

			LxfmlWriter xmlWriter = new LxfmlWriter();
			xmlWriter.writeXML(voxels);

			voxels.Clear();
			onLoading = false;
			obj.onVoxelizing = false;

			//(Instantiate(brick, m.bounds.max, Quaternion.identity) as GameObject).transform.parent = GameObject.Find("Voxelized").transform;
		
		}
	}
}
